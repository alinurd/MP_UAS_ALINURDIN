package com.example.namaproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
