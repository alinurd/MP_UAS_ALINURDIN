import 'package:flutter/material.dart';
import 'package:namaproject/layar2.dart';

void main() {
  runApp(MaterialApp(
    home: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    CounterBloc bloc = CounterBloc();
    return Scaffold(
      appBar: AppBar(
        title: Text("ALI NURDIN_19101401314 | STATE MANAGEMENT"),
      ),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          StreamBuilder(
            stream: bloc.output,
            
            builder: (context, snapshot) => Text(
              "Nilai Saat ini: ${snapshot.data} ",
              style: TextStyle(
                fontSize: 25,
              ),
            ),
          ),
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                onPressed: () {
                  bloc.inputan.add('minus');
                },
                icon: Icon(Icons.remove),
              ),
              IconButton(
                onPressed: () {
                  bloc.inputan.add('add');
                },
                icon: Icon(Icons.add),
              ),
            ],
          )
        ]),
      ),
    );
  }
}
